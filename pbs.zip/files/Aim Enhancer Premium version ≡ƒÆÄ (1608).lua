local aimbot = {}

function aimbot:initialize()
    self.target = nil
    self.sensitivity = 0.5
end

function aimbot:findTarget()
    -- Logic to find the nearest enemy target
    for _, enemy in pairs(game:getEnemies()) do
        if self:isInSight(enemy) then
            self.target = enemy
            break
        end
    end
end

function aimbot:isInSight(enemy)
    -- Check if the enemy is within the player's view
    return (self:calculateAngle(enemy) < 30) -- 30 degrees field of view
end

function aimbot:calculateAngle(enemy)
    local playerPos = game:getPlayerPosition()
    local enemyPos = enemy:getPosition()
    return math.deg(math.atan2(enemyPos.y - playerPos.y, enemyPos.x - playerPos.x))
end

function aimbot:aim()
    if self.target then
        local playerPos = game:getPlayerPosition()
        local targetPos = self.target:getPosition()
        local aimAngle = self:calculateAngle(self.target)

        -- Smooth aiming towards the target
        game:setAimAngle(playerPos, aimAngle, self.sensitivity)
    end
end

function aimbot:run()
    self:findTarget()
    self:aim()
end

return aimbot