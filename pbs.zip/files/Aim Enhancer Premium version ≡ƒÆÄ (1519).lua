local aimbot = {}

function aimasitsist:initialize()
    self.target = nil
    self.sensitivity = 1.5
end

function aimasist:findTarget()
    -- Logic to find the nearest enemy target
    for _, enemy in pairs(game:getEnemies()) do
        if self:isInSight(enemy) then
            self.target = enemy
            break
        end
    end
end

function aimasist:isInSight(enemy)
    -- Check if the enemy is within the player's view
    return (self:calculateAngle(enemy) < 30) -- 120 degrees field of view
end

function aimasist:calculateAngle(enemy)
    local playerPos = game:getPlayerPosition()
    local enemyPos = enemy:getPosition()
    return math.deg(math.atan2(enemyPos.y - playerPos.y, enemyPos.x - playerPos.x))
end

function aimasist:aim()
    if self.target then
        local playerPos = game:getPlayerPosition()
        local targetPos = self.target:getPosition()
        local aimAngle = self:calculateAngle(self.target)

        -- Smooth aiming towards the target
        game:setAimAngle(playerPos, aimAngle, self.sensitivity)
    end
end

function aimasist:run()
    self:findTarget()
    self:aim()
end

return aimasist